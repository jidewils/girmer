# Girmer

Canadian Tax Calculator & Savings Planner

## Features

- **Tax Calculator**
  - Federal and Provincial tax breakdown by bracket
  - Support for all 13 Canadian provinces/territories
  - Employee vs Self-employed calculations
  - CPP and EI deductions
  - RRSP contribution with tax savings calculation
  - Effective and marginal tax rate display
  - Visual charts (pie chart, bar chart)

- **Savings Planner**
  - Custom expense categories
  - Monthly savings calculation
  - Savings rate tracking
  - Personalized tips based on income level and savings rate
  - Emergency fund timeline
  - RRSP/TFSA recommendations

## Tech Stack

- Next.js 14 (App Router)
- React 18
- Tailwind CSS
- Recharts

## Getting Started

### Prerequisites

- Node.js 18+ 
- npm or yarn

### Installation

```bash
# Clone the repository
git clone https://github.com/yourusername/girmer.git

# Navigate to the project
cd girmer

# Install dependencies
npm install

# Run development server
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

### Deploy to Vercel

This project is optimized for Vercel deployment. Simply connect your GitHub repository to Vercel and it will auto-deploy.

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https://github.com/yourusername/girmer)

## Tax Data

Tax brackets are based on 2025 Canadian federal and provincial rates. 

**Disclaimer:** This calculator is for informational purposes only. Consult a tax professional for accurate tax advice.

## License

MIT
