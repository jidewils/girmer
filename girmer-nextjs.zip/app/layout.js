import './globals.css'

export const metadata = {
  title: 'Girmer - Canadian Tax Calculator & Savings Planner',
  description: 'Calculate your Canadian income tax, CPP, EI deductions and plan your savings with personalized tips.',
  keywords: 'Canadian tax calculator, income tax, CPP, EI, RRSP, savings planner, Ontario tax, tax brackets',
  openGraph: {
    title: 'Girmer - Canadian Tax Calculator & Savings Planner',
    description: 'Calculate your Canadian income tax and plan your savings with personalized tips.',
    type: 'website',
  },
}

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body className="bg-gray-950 text-gray-100 antialiased">
        {children}
      </body>
    </html>
  )
}
