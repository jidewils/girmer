'use client';

import React, { useState, useMemo } from 'react';
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';

// Canadian Tax Data 2025
const FEDERAL_BRACKETS = [
  { min: 0, max: 55867, rate: 0.15 },
  { min: 55867, max: 111733, rate: 0.205 },
  { min: 111733, max: 173205, rate: 0.26 },
  { min: 173205, max: 246752, rate: 0.29 },
  { min: 246752, max: Infinity, rate: 0.33 },
];

const PROVINCIAL_BRACKETS = {
  ON: [
    { min: 0, max: 51446, rate: 0.0505 },
    { min: 51446, max: 102894, rate: 0.0915 },
    { min: 102894, max: 150000, rate: 0.1116 },
    { min: 150000, max: 220000, rate: 0.1216 },
    { min: 220000, max: Infinity, rate: 0.1316 },
  ],
  BC: [
    { min: 0, max: 47937, rate: 0.0506 },
    { min: 47937, max: 95875, rate: 0.077 },
    { min: 95875, max: 110076, rate: 0.105 },
    { min: 110076, max: 133664, rate: 0.1229 },
    { min: 133664, max: 181232, rate: 0.147 },
    { min: 181232, max: Infinity, rate: 0.168 },
  ],
  AB: [
    { min: 0, max: 148269, rate: 0.10 },
    { min: 148269, max: 177922, rate: 0.12 },
    { min: 177922, max: 237230, rate: 0.13 },
    { min: 237230, max: 355845, rate: 0.14 },
    { min: 355845, max: Infinity, rate: 0.15 },
  ],
  QC: [
    { min: 0, max: 51780, rate: 0.14 },
    { min: 51780, max: 103545, rate: 0.19 },
    { min: 103545, max: 126000, rate: 0.24 },
    { min: 126000, max: Infinity, rate: 0.2575 },
  ],
  MB: [
    { min: 0, max: 47000, rate: 0.108 },
    { min: 47000, max: 100000, rate: 0.1275 },
    { min: 100000, max: Infinity, rate: 0.174 },
  ],
  SK: [
    { min: 0, max: 52057, rate: 0.105 },
    { min: 52057, max: 148734, rate: 0.125 },
    { min: 148734, max: Infinity, rate: 0.145 },
  ],
  NS: [
    { min: 0, max: 29590, rate: 0.0879 },
    { min: 29590, max: 59180, rate: 0.1495 },
    { min: 59180, max: 93000, rate: 0.1667 },
    { min: 93000, max: 150000, rate: 0.175 },
    { min: 150000, max: Infinity, rate: 0.21 },
  ],
  NB: [
    { min: 0, max: 49958, rate: 0.094 },
    { min: 49958, max: 99916, rate: 0.14 },
    { min: 99916, max: 185064, rate: 0.16 },
    { min: 185064, max: Infinity, rate: 0.195 },
  ],
  NL: [
    { min: 0, max: 43198, rate: 0.087 },
    { min: 43198, max: 86395, rate: 0.145 },
    { min: 86395, max: 154244, rate: 0.158 },
    { min: 154244, max: 215943, rate: 0.178 },
    { min: 215943, max: 275870, rate: 0.198 },
    { min: 275870, max: 551739, rate: 0.208 },
    { min: 551739, max: 1103478, rate: 0.213 },
    { min: 1103478, max: Infinity, rate: 0.218 },
  ],
  PE: [
    { min: 0, max: 32656, rate: 0.0965 },
    { min: 32656, max: 64313, rate: 0.1363 },
    { min: 64313, max: 105000, rate: 0.1665 },
    { min: 105000, max: 140000, rate: 0.18 },
    { min: 140000, max: Infinity, rate: 0.1875 },
  ],
  NT: [
    { min: 0, max: 50597, rate: 0.059 },
    { min: 50597, max: 101198, rate: 0.086 },
    { min: 101198, max: 164525, rate: 0.122 },
    { min: 164525, max: Infinity, rate: 0.1405 },
  ],
  NU: [
    { min: 0, max: 53268, rate: 0.04 },
    { min: 53268, max: 106537, rate: 0.07 },
    { min: 106537, max: 173205, rate: 0.09 },
    { min: 173205, max: Infinity, rate: 0.115 },
  ],
  YT: [
    { min: 0, max: 55867, rate: 0.064 },
    { min: 55867, max: 111733, rate: 0.09 },
    { min: 111733, max: 173205, rate: 0.109 },
    { min: 173205, max: 500000, rate: 0.128 },
    { min: 500000, max: Infinity, rate: 0.15 },
  ],
};

const PROVINCE_NAMES = {
  ON: 'Ontario',
  BC: 'British Columbia',
  AB: 'Alberta',
  QC: 'Quebec',
  MB: 'Manitoba',
  SK: 'Saskatchewan',
  NS: 'Nova Scotia',
  NB: 'New Brunswick',
  NL: 'Newfoundland & Labrador',
  PE: 'Prince Edward Island',
  NT: 'Northwest Territories',
  NU: 'Nunavut',
  YT: 'Yukon',
};

// CPP/EI Constants 2025
const CPP_MAX_EARNINGS = 71300;
const CPP_BASIC_EXEMPTION = 3500;
const CPP_RATE = 0.0595;
const CPP2_MAX_EARNINGS = 81200;
const CPP2_RATE = 0.04;
const EI_MAX_EARNINGS = 65700;
const EI_RATE = 0.0164;

// RRSP Constants 2025
const RRSP_LIMIT_2025 = 32490;
const RRSP_RATE = 0.18; // 18% of previous year's earned income

const COLORS = {
  federal: '#ef4444',
  provincial: '#f97316',
  cpp: '#eab308',
  ei: '#84cc16',
  net: '#22c55e',
  rrsp: '#8b5cf6',
  expenses: '#6366f1',
  savings: '#10b981',
};

function calculateTax(income, brackets) {
  let tax = 0;
  let details = [];
  
  for (const bracket of brackets) {
    if (income > bracket.min) {
      const taxableInBracket = Math.min(income, bracket.max) - bracket.min;
      const taxInBracket = taxableInBracket * bracket.rate;
      tax += taxInBracket;
      if (taxableInBracket > 0) {
        details.push({
          range: `$${bracket.min.toLocaleString()} - $${bracket.max === Infinity ? '+' : bracket.max.toLocaleString()}`,
          rate: (bracket.rate * 100).toFixed(2) + '%',
          taxable: taxableInBracket,
          tax: taxInBracket,
        });
      }
    }
  }
  
  return { total: tax, details };
}

function calculateCPP(income, isSelfEmployed) {
  const pensionableEarnings = Math.min(income, CPP_MAX_EARNINGS) - CPP_BASIC_EXEMPTION;
  const baseCPP = Math.max(0, pensionableEarnings) * CPP_RATE;
  
  const cpp2Earnings = Math.min(income, CPP2_MAX_EARNINGS) - CPP_MAX_EARNINGS;
  const cpp2 = Math.max(0, cpp2Earnings) * CPP2_RATE;
  
  const total = baseCPP + cpp2;
  return isSelfEmployed ? total * 2 : total;
}

function calculateEI(income, isSelfEmployed) {
  if (isSelfEmployed) return 0;
  return Math.min(income, EI_MAX_EARNINGS) * EI_RATE;
}

function generateSavingsTips(grossIncome, netMonthly, savingsRate, totalExpenses, monthlySavings, rrspContribution) {
  const tips = [];
  const annualNet = netMonthly * 12;
  
  // Income tier detection
  const isLowIncome = grossIncome < 50000;
  const isMidIncome = grossIncome >= 50000 && grossIncome < 100000;
  const isHighIncome = grossIncome >= 100000 && grossIncome < 200000;
  const isVeryHighIncome = grossIncome >= 200000;
  
  // Calculate suggested savings amounts
  const suggested10Percent = netMonthly * 0.10;
  const suggested15Percent = netMonthly * 0.15;
  const suggested20Percent = netMonthly * 0.20;
  const suggested25Percent = netMonthly * 0.25;
  const suggested30Percent = netMonthly * 0.30;
  
  // Emergency fund calculations
  const emergencyFund3Months = totalExpenses * 3;
  const emergencyFund6Months = totalExpenses * 6;
  
  // RRSP calculations
  const maxRRSP = Math.min(grossIncome * RRSP_RATE, RRSP_LIMIT_2025);
  const remainingRRSPRoom = Math.max(0, maxRRSP - rrspContribution);
  
  // TFSA
  const tfsaAnnualLimit = 7000;
  const tfsaMonthly = Math.round(tfsaAnnualLimit / 12);
  
  // ===== SAVINGS RATE BASED TIPS =====
  if (savingsRate < 0) {
    tips.push({
      icon: '🚨',
      title: 'Spending Exceeds Income',
      description: `You're spending $${Math.abs(monthlySavings).toLocaleString()} more than you earn. Review your expenses urgently — look for subscriptions to cancel, negotiate bills, or find ways to increase income.`,
      priority: 'critical'
    });
  } else if (savingsRate < 5) {
    tips.push({
      icon: '⚠️',
      title: 'Build Your Safety Net First',
      description: `At ${savingsRate.toFixed(1)}% savings rate, focus on building a $1,000 emergency starter fund before anything else. Try the "no-spend challenge" for one category each month.`,
      priority: 'high'
    });
  } else if (savingsRate < 10) {
    tips.push({
      icon: '📈',
      title: 'Push Toward 10%',
      description: `You're saving $${monthlySavings.toLocaleString(undefined, {maximumFractionDigits: 0})}/month (${savingsRate.toFixed(1)}%). Adding just $${(suggested10Percent - monthlySavings).toLocaleString(undefined, {maximumFractionDigits: 0})} more would hit the 10% benchmark — that's ${((suggested10Percent - monthlySavings) / 30).toFixed(0)} less per day.`,
      priority: 'medium'
    });
  } else if (savingsRate < 15) {
    tips.push({
      icon: '✅',
      title: 'Solid Foundation — Now Optimize',
      description: `${savingsRate.toFixed(1)}% is good! To reach 15% ($${suggested15Percent.toLocaleString(undefined, {maximumFractionDigits: 0})}/month), consider automating an extra $${(suggested15Percent - monthlySavings).toLocaleString(undefined, {maximumFractionDigits: 0})} transfer on payday.`,
      priority: 'low'
    });
  } else if (savingsRate < 20) {
    tips.push({
      icon: '🎯',
      title: 'Above Average — Keep Pushing',
      description: `At ${savingsRate.toFixed(1)}%, you're ahead of most Canadians. The 20% mark ($${suggested20Percent.toLocaleString(undefined, {maximumFractionDigits: 0})}/month) is where wealth building accelerates.`,
      priority: 'low'
    });
  } else if (savingsRate < 30) {
    tips.push({
      icon: '🏆',
      title: 'Excellent Saver',
      description: `${savingsRate.toFixed(1)}% savings rate puts you in the top tier. At $${monthlySavings.toLocaleString(undefined, {maximumFractionDigits: 0})}/month, you'll save $${(monthlySavings * 12).toLocaleString(undefined, {maximumFractionDigits: 0})}/year. Consider if you can push to 30% for early financial independence.`,
      priority: 'info'
    });
  } else {
    tips.push({
      icon: '🔥',
      title: 'Financial Independence Track',
      description: `${savingsRate.toFixed(1)}% is exceptional! At this rate, you could potentially reach financial independence in 15-20 years. Make sure you're not sacrificing quality of life — balance is key.`,
      priority: 'info'
    });
  }
  
  // ===== INCOME-BASED TIPS =====
  if (isLowIncome) {
    tips.push({
      icon: '💡',
      title: 'Maximize Government Benefits',
      description: `At your income level, ensure you're claiming: GST/HST credit (up to $519/year), Canada Workers Benefit (up to $1,518), and provincial benefits. File taxes even with low income to access these.`,
      priority: 'high'
    });
    
    tips.push({
      icon: '🏦',
      title: 'TFSA Over RRSP',
      description: `With income under $50K, prioritize TFSA first. RRSP deductions are more valuable at higher tax brackets — save that room for when your income grows.`,
      priority: 'medium'
    });
  }
  
  if (isMidIncome) {
    tips.push({
      icon: '⚖️',
      title: 'Balance TFSA and RRSP',
      description: `At $${grossIncome.toLocaleString()} income, split contributions: TFSA for flexible savings, RRSP for tax deduction. Your RRSP contribution could save ~$${(Math.min(5000, remainingRRSPRoom) * 0.30).toLocaleString(undefined, {maximumFractionDigits: 0})} in taxes.`,
      priority: 'medium'
    });
    
    if (monthlySavings > 500) {
      tips.push({
        icon: '📊',
        title: 'Start Investing',
        description: `With $${monthlySavings.toLocaleString(undefined, {maximumFractionDigits: 0})}/month to save, consider low-cost index ETFs. A simple 3-fund portfolio (Canadian, US, International) can be set up with $${Math.min(monthlySavings, 500).toLocaleString()}/month auto-investments.`,
        priority: 'medium'
      });
    }
  }
  
  if (isHighIncome) {
    tips.push({
      icon: '🎯',
      title: 'Max Out Registered Accounts',
      description: `Your income supports maxing RRSP ($${maxRRSP.toLocaleString(undefined, {maximumFractionDigits: 0})}/year) and TFSA ($${tfsaAnnualLimit.toLocaleString()}/year). That's $${((maxRRSP + tfsaAnnualLimit) / 12).toLocaleString(undefined, {maximumFractionDigits: 0})}/month in tax-advantaged savings.`,
      priority: 'high'
    });
    
    tips.push({
      icon: '💼',
      title: 'Consider Income Splitting',
      description: `If you have a spouse with lower income, spousal RRSP contributions can reduce family tax burden. Also explore pension income splitting if applicable.`,
      priority: 'medium'
    });
    
    tips.push({
      icon: '🏠',
      title: 'First Home Savings Account (FHSA)',
      description: `If you're a first-time home buyer, the FHSA offers $8,000/year contribution room with tax deduction AND tax-free growth. It's like RRSP + TFSA combined.`,
      priority: 'medium'
    });
  }
  
  if (isVeryHighIncome) {
    tips.push({
      icon: '🏛️',
      title: 'Beyond Registered Accounts',
      description: `After maxing RRSP and TFSA, consider: non-registered investments (tax-efficient ETFs), corporate class funds, or if self-employed, incorporating for tax deferral.`,
      priority: 'high'
    });
    
    tips.push({
      icon: '📋',
      title: 'Tax Planning Strategies',
      description: `At $${grossIncome.toLocaleString()} income, professional tax planning pays for itself. Consider: charitable donation strategies, capital gains timing, prescribed rate loans for income splitting.`,
      priority: 'high'
    });
    
    tips.push({
      icon: '🛡️',
      title: 'Protect Your Income',
      description: `Your high income is your biggest asset. Ensure adequate disability insurance (aim for 60-70% income replacement) and consider umbrella liability coverage.`,
      priority: 'medium'
    });
  }
  
  // ===== RRSP SPECIFIC TIPS =====
  if (rrspContribution > 0) {
    tips.push({
      icon: '💰',
      title: 'RRSP Tax Refund Strategy',
      description: `Your $${rrspContribution.toLocaleString()} RRSP contribution will generate a tax refund. Pro tip: Reinvest that refund into your TFSA or next year's RRSP to compound the benefit.`,
      priority: 'medium'
    });
  }
  
  if (remainingRRSPRoom > 5000 && grossIncome > 60000) {
    tips.push({
      icon: '📅',
      title: 'RRSP Room Available',
      description: `You have ~$${remainingRRSPRoom.toLocaleString(undefined, {maximumFractionDigits: 0})} RRSP room remaining. Contributing $${Math.min(remainingRRSPRoom, monthlySavings * 3).toLocaleString(undefined, {maximumFractionDigits: 0})} more could save ~$${(Math.min(remainingRRSPRoom, monthlySavings * 3) * 0.30).toLocaleString(undefined, {maximumFractionDigits: 0})} in taxes.`,
      priority: 'medium'
    });
  }
  
  // ===== EMERGENCY FUND TIPS =====
  if (totalExpenses > 0) {
    if (monthlySavings > 0 && monthlySavings < emergencyFund3Months / 6) {
      const monthsToGoal = Math.ceil(emergencyFund3Months / monthlySavings);
      tips.push({
        icon: '🏦',
        title: 'Emergency Fund Timeline',
        description: `At $${monthlySavings.toLocaleString(undefined, {maximumFractionDigits: 0})}/month savings, you'll reach a 3-month emergency fund ($${emergencyFund3Months.toLocaleString(undefined, {maximumFractionDigits: 0})}) in ${monthsToGoal} months. Keep it in a high-interest savings account (2-4% available).`,
        priority: 'medium'
      });
    } else if (monthlySavings >= emergencyFund3Months / 6) {
      tips.push({
        icon: '✨',
        title: 'Fast-Track Emergency Fund',
        description: `Great news! You can build a 3-month emergency fund ($${emergencyFund3Months.toLocaleString(undefined, {maximumFractionDigits: 0})}) in under 6 months. Consider a 6-month fund ($${emergencyFund6Months.toLocaleString(undefined, {maximumFractionDigits: 0})}) for extra security.`,
        priority: 'low'
      });
    }
  }
  
  // ===== EXPENSE-BASED TIPS =====
  if (totalExpenses > netMonthly * 0.7) {
    tips.push({
      icon: '🔍',
      title: 'High Expense Ratio',
      description: `Your expenses consume ${((totalExpenses / netMonthly) * 100).toFixed(0)}% of income. The 50/30/20 rule suggests max 50% on needs. Review your largest expense categories for potential cuts.`,
      priority: 'high'
    });
  }
  
  // ===== AUTOMATION TIP =====
  tips.push({
    icon: '🤖',
    title: 'Automate Your Savings',
    description: `Set up automatic transfers on payday: $${suggested15Percent.toLocaleString(undefined, {maximumFractionDigits: 0})} to savings (15%), $${tfsaMonthly} to TFSA, and $${Math.round(maxRRSP / 12).toLocaleString()} to RRSP. What you don't see, you won't spend.`,
    priority: 'low'
  });
  
  // ===== INVESTMENT GROWTH TIP =====
  if (monthlySavings > 200) {
    const futureValue10Years = monthlySavings * 12 * 10 * 1.4; // Rough estimate with 7% annual return compounded
    const futureValue20Years = monthlySavings * 12 * 20 * 2.0;
    tips.push({
      icon: '📈',
      title: 'Power of Compound Growth',
      description: `Investing $${monthlySavings.toLocaleString(undefined, {maximumFractionDigits: 0})}/month at 7% average return: ~$${(futureValue10Years / 1000).toFixed(0)}K in 10 years, ~$${(futureValue20Years / 1000).toFixed(0)}K in 20 years. Time in the market beats timing the market.`,
      priority: 'info'
    });
  }
  
  // ===== LIFESTYLE TIPS =====
  if (savingsRate >= 20 && grossIncome > 80000) {
    tips.push({
      icon: '🎉',
      title: "Don't Forget to Live",
      description: `You're saving well! Consider allocating 5-10% ($${(netMonthly * 0.05).toLocaleString(undefined, {maximumFractionDigits: 0})}-$${(netMonthly * 0.10).toLocaleString(undefined, {maximumFractionDigits: 0})}/month) as "fun money" — guilt-free spending on experiences and things you enjoy.`,
      priority: 'info'
    });
  }
  
  // Sort by priority
  const priorityOrder = { critical: 0, high: 1, medium: 2, low: 3, info: 4 };
  tips.sort((a, b) => priorityOrder[a.priority] - priorityOrder[b.priority]);
  
  return tips;
}

export default function Girmer() {
  const [step, setStep] = useState(1);
  const [grossIncome, setGrossIncome] = useState('');
  const [province, setProvince] = useState('ON');
  const [employmentType, setEmploymentType] = useState('employee');
  const [rrspContribution, setRrspContribution] = useState('');
  const [expenses, setExpenses] = useState([
    { id: 1, name: 'Rent / Mortgage', amount: '' },
    { id: 2, name: 'Utilities', amount: '' },
    { id: 3, name: 'Groceries', amount: '' },
    { id: 4, name: 'Transportation', amount: '' },
    { id: 5, name: 'Insurance', amount: '' },
    { id: 6, name: 'Subscriptions', amount: '' },
  ]);
  const [newExpenseName, setNewExpenseName] = useState('');

  const isSelfEmployed = employmentType === 'self-employed';
  const income = parseFloat(grossIncome) || 0;
  const rrsp = parseFloat(rrspContribution) || 0;
  
  // Calculate max RRSP room
  const maxRRSPRoom = Math.min(income * RRSP_RATE, RRSP_LIMIT_2025);
  const validRRSP = Math.min(rrsp, maxRRSPRoom);

  const calculations = useMemo(() => {
    if (income === 0) return null;

    // Taxable income is reduced by RRSP contribution
    const taxableIncome = Math.max(0, income - validRRSP);
    
    const federalTax = calculateTax(taxableIncome, FEDERAL_BRACKETS);
    const provincialTax = calculateTax(taxableIncome, PROVINCIAL_BRACKETS[province]);
    
    // CPP and EI are based on gross income, not reduced by RRSP
    const cpp = calculateCPP(income, isSelfEmployed);
    const ei = calculateEI(income, isSelfEmployed);
    
    // Calculate tax without RRSP for comparison
    const federalTaxNoRRSP = calculateTax(income, FEDERAL_BRACKETS);
    const provincialTaxNoRRSP = calculateTax(income, PROVINCIAL_BRACKETS[province]);
    const taxWithoutRRSP = federalTaxNoRRSP.total + provincialTaxNoRRSP.total;
    const taxWithRRSP = federalTax.total + provincialTax.total;
    const rrspTaxSavings = taxWithoutRRSP - taxWithRRSP;
    
    const totalDeductions = federalTax.total + provincialTax.total + cpp + ei;
    const netAnnual = income - totalDeductions - validRRSP;
    const netMonthly = netAnnual / 12;
    
    const effectiveRate = (totalDeductions / income) * 100;
    const lastFederalBracket = FEDERAL_BRACKETS.find(b => taxableIncome <= b.max) || FEDERAL_BRACKETS[FEDERAL_BRACKETS.length - 1];
    const lastProvincialBracket = PROVINCIAL_BRACKETS[province].find(b => taxableIncome <= b.max) || PROVINCIAL_BRACKETS[province][PROVINCIAL_BRACKETS[province].length - 1];
    const marginalRate = (lastFederalBracket.rate + lastProvincialBracket.rate) * 100;

    return {
      taxableIncome,
      federalTax,
      provincialTax,
      cpp,
      ei,
      totalDeductions,
      netAnnual,
      netMonthly,
      effectiveRate,
      marginalRate,
      rrspTaxSavings,
      validRRSP,
      maxRRSPRoom,
    };
  }, [income, province, isSelfEmployed, validRRSP]);

  const savingsCalculations = useMemo(() => {
    if (!calculations) return null;
    
    const totalExpenses = expenses.reduce((sum, exp) => sum + (parseFloat(exp.amount) || 0), 0);
    const monthlySavings = calculations.netMonthly - totalExpenses;
    const savingsRate = calculations.netMonthly > 0 ? (monthlySavings / calculations.netMonthly) * 100 : 0;
    
    return {
      totalExpenses,
      monthlySavings,
      savingsRate,
    };
  }, [calculations, expenses]);

  const savingsTips = useMemo(() => {
    if (!calculations || !savingsCalculations) return [];
    return generateSavingsTips(
      income,
      calculations.netMonthly,
      savingsCalculations.savingsRate,
      savingsCalculations.totalExpenses,
      savingsCalculations.monthlySavings,
      validRRSP
    );
  }, [income, calculations, savingsCalculations, validRRSP]);

  const addExpense = () => {
    if (newExpenseName.trim()) {
      setExpenses([...expenses, { id: Date.now(), name: newExpenseName.trim(), amount: '' }]);
      setNewExpenseName('');
    }
  };

  const updateExpense = (id, amount) => {
    setExpenses(expenses.map(exp => exp.id === id ? { ...exp, amount } : exp));
  };

  const removeExpense = (id) => {
    setExpenses(expenses.filter(exp => exp.id !== id));
  };

  const pieData = calculations ? [
    { name: 'Federal Tax', value: calculations.federalTax.total, color: COLORS.federal },
    { name: 'Provincial Tax', value: calculations.provincialTax.total, color: COLORS.provincial },
    { name: 'CPP', value: calculations.cpp, color: COLORS.cpp },
    { name: 'EI', value: calculations.ei, color: COLORS.ei },
    { name: 'RRSP', value: calculations.validRRSP, color: COLORS.rrsp },
    { name: 'Net Income', value: calculations.netAnnual, color: COLORS.net },
  ].filter(d => d.value > 0) : [];

  const barData = calculations ? [
    { name: 'Gross', amount: income },
    { name: 'Federal', amount: -calculations.federalTax.total },
    { name: 'Provincial', amount: -calculations.provincialTax.total },
    { name: 'CPP', amount: -calculations.cpp },
    { name: 'EI', amount: -calculations.ei },
    { name: 'RRSP', amount: -calculations.validRRSP },
    { name: 'Net', amount: calculations.netAnnual },
  ].filter(d => d.name === 'Gross' || d.name === 'Net' || d.amount !== 0) : [];

  return (
    <div className="min-h-screen bg-gray-950 text-gray-100">
      {/* Header */}
      <header className="border-b border-gray-800 bg-gray-900/50 backdrop-blur-sm sticky top-0 z-10">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <h1 className="text-2xl font-bold text-emerald-400">Girmer</h1>
          <div className="flex gap-2">
            <button
              onClick={() => setStep(1)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                step === 1 ? 'bg-emerald-600 text-white' : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
              }`}
            >
              Tax Calculator
            </button>
            <button
              onClick={() => setStep(2)}
              disabled={!calculations}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                step === 2 ? 'bg-emerald-600 text-white' : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
              } ${!calculations ? 'opacity-50 cursor-not-allowed' : ''}`}
            >
              Savings Planner
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-8">
        {step === 1 ? (
          <>
            {/* Input Section */}
            <div className="bg-gray-900 rounded-2xl p-6 mb-8 border border-gray-800">
              <h2 className="text-xl font-semibold mb-6 text-gray-100">Enter Your Income Details</h2>
              
              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-2">
                    Gross Annual Income
                  </label>
                  <div className="relative">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500">$</span>
                    <input
                      type="number"
                      value={grossIncome}
                      onChange={(e) => setGrossIncome(e.target.value)}
                      placeholder="150,000"
                      className="w-full bg-gray-800 border border-gray-700 rounded-xl py-3 pl-8 pr-4 text-lg font-medium text-gray-100 placeholder-gray-600 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                    />
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-2">
                    Province / Territory
                  </label>
                  <select
                    value={province}
                    onChange={(e) => setProvince(e.target.value)}
                    className="w-full bg-gray-800 border border-gray-700 rounded-xl py-3 px-4 text-lg font-medium text-gray-100 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent appearance-none cursor-pointer"
                  >
                    {Object.entries(PROVINCE_NAMES).map(([code, name]) => (
                      <option key={code} value={code}>{name}</option>
                    ))}
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-2">
                    Employment Type
                  </label>
                  <select
                    value={employmentType}
                    onChange={(e) => setEmploymentType(e.target.value)}
                    className="w-full bg-gray-800 border border-gray-700 rounded-xl py-3 px-4 text-lg font-medium text-gray-100 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent appearance-none cursor-pointer"
                  >
                    <option value="employee">Employee</option>
                    <option value="self-employed">Self-Employed / Freelancer</option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-2">
                    RRSP Contribution
                    {income > 0 && (
                      <span className="text-gray-600 ml-1">(max: ${maxRRSPRoom.toLocaleString(undefined, {maximumFractionDigits: 0})})</span>
                    )}
                  </label>
                  <div className="relative">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500">$</span>
                    <input
                      type="number"
                      value={rrspContribution}
                      onChange={(e) => setRrspContribution(e.target.value)}
                      placeholder="0"
                      max={maxRRSPRoom}
                      className="w-full bg-gray-800 border border-gray-700 rounded-xl py-3 pl-8 pr-4 text-lg font-medium text-gray-100 placeholder-gray-600 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                    />
                  </div>
                </div>
              </div>
              
              {/* RRSP Info Box */}
              {income > 0 && (
                <div className="mt-4 p-4 bg-purple-900/20 border border-purple-800/50 rounded-xl">
                  <div className="flex items-start gap-3">
                    <span className="text-purple-400 text-lg">💡</span>
                    <div className="text-sm">
                      <p className="text-purple-300 font-medium">RRSP Tax Benefit</p>
                      <p className="text-gray-400 mt-1">
                        RRSP contributions reduce your taxable income. Your 2025 limit is 18% of income up to ${RRSP_LIMIT_2025.toLocaleString()}.
                        {validRRSP > 0 && calculations && (
                          <span className="text-purple-400 font-medium">
                            {' '}Your ${validRRSP.toLocaleString()} contribution saves ~${calculations.rrspTaxSavings.toLocaleString(undefined, {maximumFractionDigits: 0})} in taxes!
                          </span>
                        )}
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {calculations && (
              <>
                {/* Summary Cards */}
                <div className="grid md:grid-cols-2 lg:grid-cols-5 gap-4 mb-8">
                  <div className="bg-gray-900 rounded-2xl p-5 border border-gray-800">
                    <p className="text-sm text-gray-400 mb-1">Gross Income</p>
                    <p className="text-2xl font-bold text-gray-100">${income.toLocaleString()}</p>
                    <p className="text-sm text-gray-500">${(income / 12).toLocaleString(undefined, { maximumFractionDigits: 0 })}/mo</p>
                  </div>
                  
                  {validRRSP > 0 && (
                    <div className="bg-purple-900/30 rounded-2xl p-5 border border-purple-800">
                      <p className="text-sm text-purple-400 mb-1">RRSP Contribution</p>
                      <p className="text-2xl font-bold text-purple-400">-${validRRSP.toLocaleString()}</p>
                      <p className="text-sm text-purple-600">Saves ${calculations.rrspTaxSavings.toLocaleString(undefined, {maximumFractionDigits: 0})} tax</p>
                    </div>
                  )}
                  
                  <div className="bg-gray-900 rounded-2xl p-5 border border-gray-800">
                    <p className="text-sm text-gray-400 mb-1">Total Tax & Deductions</p>
                    <p className="text-2xl font-bold text-red-400">-${calculations.totalDeductions.toLocaleString(undefined, { maximumFractionDigits: 0 })}</p>
                    <p className="text-sm text-gray-500">-${(calculations.totalDeductions / 12).toLocaleString(undefined, { maximumFractionDigits: 0 })}/mo</p>
                  </div>
                  
                  <div className="bg-emerald-900/30 rounded-2xl p-5 border border-emerald-800">
                    <p className="text-sm text-emerald-400 mb-1">Net Income</p>
                    <p className="text-2xl font-bold text-emerald-400">${calculations.netAnnual.toLocaleString(undefined, { maximumFractionDigits: 0 })}</p>
                    <p className="text-sm text-emerald-600">${calculations.netMonthly.toLocaleString(undefined, { maximumFractionDigits: 0 })}/mo</p>
                  </div>
                  
                  <div className="bg-gray-900 rounded-2xl p-5 border border-gray-800">
                    <p className="text-sm text-gray-400 mb-1">Tax Rates</p>
                    <p className="text-lg font-bold text-gray-100">{calculations.effectiveRate.toFixed(1)}% <span className="text-sm font-normal text-gray-500">effective</span></p>
                    <p className="text-lg font-bold text-gray-100">{calculations.marginalRate.toFixed(1)}% <span className="text-sm font-normal text-gray-500">marginal</span></p>
                  </div>
                </div>

                {/* Charts */}
                <div className="grid md:grid-cols-2 gap-6 mb-8">
                  <div className="bg-gray-900 rounded-2xl p-6 border border-gray-800">
                    <h3 className="text-lg font-semibold mb-4 text-gray-100">Income Distribution</h3>
                    <ResponsiveContainer width="100%" height={280}>
                      <PieChart>
                        <Pie
                          data={pieData}
                          cx="50%"
                          cy="50%"
                          innerRadius={60}
                          outerRadius={100}
                          paddingAngle={2}
                          dataKey="value"
                        >
                          {pieData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Pie>
                        <Tooltip
                          formatter={(value) => `$${value.toLocaleString(undefined, { maximumFractionDigits: 0 })}`}
                          contentStyle={{ backgroundColor: '#1f2937', border: 'none', borderRadius: '8px', color: '#ffffff' }}
                          labelStyle={{ color: '#ffffff' }}
                          itemStyle={{ color: '#ffffff' }}
                        />
                      </PieChart>
                    </ResponsiveContainer>
                    <div className="flex flex-wrap justify-center gap-4 mt-4">
                      {pieData.map((entry) => (
                        <div key={entry.name} className="flex items-center gap-2">
                          <div className="w-3 h-3 rounded-full" style={{ backgroundColor: entry.color }} />
                          <span className="text-xs text-gray-400">{entry.name}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="bg-gray-900 rounded-2xl p-6 border border-gray-800">
                    <h3 className="text-lg font-semibold mb-4 text-gray-100">Deduction Breakdown</h3>
                    <ResponsiveContainer width="100%" height={280}>
                      <BarChart data={barData} layout="vertical">
                        <XAxis type="number" tickFormatter={(v) => `$${(v / 1000).toFixed(0)}k`} stroke="#6b7280" />
                        <YAxis type="category" dataKey="name" stroke="#6b7280" width={70} />
                        <Tooltip
                          formatter={(value) => `$${Math.abs(value).toLocaleString(undefined, { maximumFractionDigits: 0 })}`}
                          contentStyle={{ backgroundColor: '#1f2937', border: 'none', borderRadius: '8px', color: '#ffffff' }}
                          labelStyle={{ color: '#ffffff' }}
                          itemStyle={{ color: '#ffffff' }}
                        />
                        <Bar dataKey="amount" radius={[0, 4, 4, 0]}>
                          {barData.map((entry, index) => (
                            <Cell
                              key={`cell-${index}`}
                              fill={
                                entry.name === 'RRSP' ? COLORS.rrsp :
                                entry.amount >= 0 ? COLORS.net : COLORS.federal
                              }
                            />
                          ))}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                {/* Detailed Breakdown */}
                <div className="grid md:grid-cols-2 gap-6 mb-8">
                  {/* Federal Tax */}
                  <div className="bg-gray-900 rounded-2xl p-6 border border-gray-800">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-lg font-semibold text-gray-100">Federal Tax</h3>
                      <span className="text-xl font-bold text-red-400">
                        -${calculations.federalTax.total.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                      </span>
                    </div>
                    {validRRSP > 0 && (
                      <p className="text-xs text-purple-400 mb-3">Taxable income: ${calculations.taxableIncome.toLocaleString()} (after RRSP deduction)</p>
                    )}
                    <div className="space-y-3">
                      {calculations.federalTax.details.map((bracket, i) => (
                        <div key={i} className="flex items-center justify-between text-sm">
                          <div>
                            <span className="text-gray-400">{bracket.range}</span>
                            <span className="text-gray-600 ml-2">@ {bracket.rate}</span>
                          </div>
                          <span className="text-gray-300">${bracket.tax.toLocaleString(undefined, { maximumFractionDigits: 0 })}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Provincial Tax */}
                  <div className="bg-gray-900 rounded-2xl p-6 border border-gray-800">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-lg font-semibold text-gray-100">{PROVINCE_NAMES[province]} Tax</h3>
                      <span className="text-xl font-bold text-orange-400">
                        -${calculations.provincialTax.total.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                      </span>
                    </div>
                    {validRRSP > 0 && (
                      <p className="text-xs text-purple-400 mb-3">Taxable income: ${calculations.taxableIncome.toLocaleString()} (after RRSP deduction)</p>
                    )}
                    <div className="space-y-3">
                      {calculations.provincialTax.details.map((bracket, i) => (
                        <div key={i} className="flex items-center justify-between text-sm">
                          <div>
                            <span className="text-gray-400">{bracket.range}</span>
                            <span className="text-gray-600 ml-2">@ {bracket.rate}</span>
                          </div>
                          <span className="text-gray-300">${bracket.tax.toLocaleString(undefined, { maximumFractionDigits: 0 })}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* CPP & EI */}
                <div className="grid md:grid-cols-2 gap-6 mb-8">
                  <div className="bg-gray-900 rounded-2xl p-6 border border-gray-800">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="text-lg font-semibold text-gray-100">CPP Contributions</h3>
                      <span className="text-xl font-bold text-yellow-400">
                        -${calculations.cpp.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                      </span>
                    </div>
                    <p className="text-sm text-gray-500">
                      {isSelfEmployed 
                        ? 'As self-employed, you pay both employee and employer portions (2x)'
                        : 'Employee contribution (employer pays matching amount)'}
                    </p>
                  </div>

                  <div className="bg-gray-900 rounded-2xl p-6 border border-gray-800">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="text-lg font-semibold text-gray-100">EI Premiums</h3>
                      <span className="text-xl font-bold text-lime-400">
                        {isSelfEmployed ? '$0' : `-$${calculations.ei.toLocaleString(undefined, { maximumFractionDigits: 0 })}`}
                      </span>
                    </div>
                    <p className="text-sm text-gray-500">
                      {isSelfEmployed 
                        ? 'Self-employed individuals are exempt from EI (optional enrollment available)'
                        : 'Employment Insurance premiums'}
                    </p>
                  </div>
                </div>

                {/* CTA to Savings */}
                <div className="bg-gradient-to-r from-emerald-900/50 to-teal-900/50 rounded-2xl p-8 border border-emerald-800 text-center">
                  <h3 className="text-2xl font-bold text-emerald-400 mb-2">
                    You'll take home ${calculations.netMonthly.toLocaleString(undefined, { maximumFractionDigits: 0 })} per month
                  </h3>
                  <p className="text-gray-400 mb-6">Now let's plan how to make the most of it</p>
                  <button
                    onClick={() => setStep(2)}
                    className="bg-emerald-600 hover:bg-emerald-500 text-white font-semibold px-8 py-3 rounded-xl transition-colors"
                  >
                    Plan Your Savings →
                  </button>
                </div>
              </>
            )}
          </>
        ) : (
          <>
            {/* Savings Planner */}
            <div className="mb-8">
              <button
                onClick={() => setStep(1)}
                className="text-gray-400 hover:text-gray-200 text-sm mb-4 flex items-center gap-2"
              >
                ← Back to Tax Calculator
              </button>
              
              <div className="bg-emerald-900/30 rounded-2xl p-6 border border-emerald-800 mb-8">
                <p className="text-sm text-emerald-400 mb-1">Your Monthly Net Income</p>
                <p className="text-4xl font-bold text-emerald-400">
                  ${calculations?.netMonthly.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                </p>
              </div>
            </div>

            {/* Expenses Input */}
            <div className="bg-gray-900 rounded-2xl p-6 border border-gray-800 mb-8">
              <h2 className="text-xl font-semibold mb-6 text-gray-100">Monthly Expenses</h2>
              <p className="text-sm text-gray-500 mb-6">All fields are optional. Add your expenses to see how much you can save.</p>
              
              <div className="grid md:grid-cols-2 gap-4 mb-6">
                {expenses.map((expense) => (
                  <div key={expense.id} className="flex items-center gap-3">
                    <div className="flex-1">
                      <label className="block text-sm text-gray-400 mb-1">{expense.name}</label>
                      <div className="relative">
                        <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500">$</span>
                        <input
                          type="number"
                          value={expense.amount}
                          onChange={(e) => updateExpense(expense.id, e.target.value)}
                          placeholder="0"
                          className="w-full bg-gray-800 border border-gray-700 rounded-lg py-2 pl-8 pr-3 text-gray-100 placeholder-gray-600 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                        />
                      </div>
                    </div>
                    <button
                      onClick={() => removeExpense(expense.id)}
                      className="mt-6 text-gray-600 hover:text-red-400 transition-colors"
                    >
                      ✕
                    </button>
                  </div>
                ))}
              </div>

              {/* Add Custom Expense */}
              <div className="flex gap-3">
                <input
                  type="text"
                  value={newExpenseName}
                  onChange={(e) => setNewExpenseName(e.target.value)}
                  placeholder="Add custom expense..."
                  className="flex-1 bg-gray-800 border border-gray-700 rounded-lg py-2 px-4 text-gray-100 placeholder-gray-600 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                  onKeyPress={(e) => e.key === 'Enter' && addExpense()}
                />
                <button
                  onClick={addExpense}
                  className="bg-gray-700 hover:bg-gray-600 text-gray-200 px-4 py-2 rounded-lg transition-colors"
                >
                  + Add
                </button>
              </div>
            </div>

            {/* Savings Summary */}
            {savingsCalculations && (
              <div className="grid md:grid-cols-3 gap-4 mb-8">
                <div className="bg-gray-900 rounded-2xl p-5 border border-gray-800">
                  <p className="text-sm text-gray-400 mb-1">Total Expenses</p>
                  <p className="text-2xl font-bold text-indigo-400">
                    ${savingsCalculations.totalExpenses.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                  </p>
                  <p className="text-sm text-gray-500">/month</p>
                </div>
                
                <div className={`rounded-2xl p-5 border ${
                  savingsCalculations.monthlySavings >= 0 
                    ? 'bg-emerald-900/30 border-emerald-800' 
                    : 'bg-red-900/30 border-red-800'
                }`}>
                  <p className={`text-sm mb-1 ${savingsCalculations.monthlySavings >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                    Monthly Savings
                  </p>
                  <p className={`text-2xl font-bold ${savingsCalculations.monthlySavings >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                    ${savingsCalculations.monthlySavings.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                  </p>
                  <p className={`text-sm ${savingsCalculations.monthlySavings >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
                    ${(savingsCalculations.monthlySavings * 12).toLocaleString(undefined, { maximumFractionDigits: 0 })}/year
                  </p>
                </div>
                
                <div className="bg-gray-900 rounded-2xl p-5 border border-gray-800">
                  <p className="text-sm text-gray-400 mb-1">Savings Rate</p>
                  <p className={`text-2xl font-bold ${
                    savingsCalculations.savingsRate >= 20 ? 'text-emerald-400' :
                    savingsCalculations.savingsRate >= 10 ? 'text-yellow-400' : 'text-red-400'
                  }`}>
                    {savingsCalculations.savingsRate.toFixed(1)}%
                  </p>
                  <p className="text-sm text-gray-500">
                    {savingsCalculations.savingsRate >= 20 ? 'Excellent!' :
                     savingsCalculations.savingsRate >= 10 ? 'Good progress' : 'Needs attention'}
                  </p>
                </div>
              </div>
            )}

            {/* Visual Breakdown */}
            {savingsCalculations && savingsCalculations.totalExpenses > 0 && (
              <div className="bg-gray-900 rounded-2xl p-6 border border-gray-800 mb-8">
                <h3 className="text-lg font-semibold mb-4 text-gray-100">Where Your Money Goes</h3>
                <div className="space-y-3">
                  {expenses.filter(e => parseFloat(e.amount) > 0).map((expense) => {
                    const amount = parseFloat(expense.amount) || 0;
                    const percentage = (amount / calculations.netMonthly) * 100;
                    return (
                      <div key={expense.id}>
                        <div className="flex justify-between text-sm mb-1">
                          <span className="text-gray-400">{expense.name}</span>
                          <span className="text-gray-300">${amount.toLocaleString()} ({percentage.toFixed(1)}%)</span>
                        </div>
                        <div className="h-2 bg-gray-800 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-indigo-500 rounded-full"
                            style={{ width: `${Math.min(percentage, 100)}%` }}
                          />
                        </div>
                      </div>
                    );
                  })}
                  
                  {savingsCalculations.monthlySavings > 0 && (
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span className="text-emerald-400 font-medium">Savings</span>
                        <span className="text-emerald-400">
                          ${savingsCalculations.monthlySavings.toLocaleString(undefined, { maximumFractionDigits: 0 })} ({savingsCalculations.savingsRate.toFixed(1)}%)
                        </span>
                      </div>
                      <div className="h-2 bg-gray-800 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-emerald-500 rounded-full"
                          style={{ width: `${Math.min(savingsCalculations.savingsRate, 100)}%` }}
                        />
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Personalized Tips */}
            {savingsTips.length > 0 && (
              <div className="bg-gray-900 rounded-2xl p-6 border border-gray-800">
                <h3 className="text-lg font-semibold mb-6 text-gray-100">💡 Personalized Savings Tips</h3>
                <div className="space-y-4">
                  {savingsTips.map((tip, index) => (
                    <div 
                      key={index} 
                      className={`p-4 rounded-xl border ${
                        tip.priority === 'critical' ? 'bg-red-900/20 border-red-800' :
                        tip.priority === 'high' ? 'bg-orange-900/20 border-orange-800' :
                        tip.priority === 'medium' ? 'bg-blue-900/20 border-blue-800' :
                        tip.priority === 'low' ? 'bg-gray-800/50 border-gray-700' :
                        'bg-emerald-900/20 border-emerald-800'
                      }`}
                    >
                      <div className="flex items-start gap-3">
                        <span className="text-2xl">{tip.icon}</span>
                        <div>
                          <h4 className={`font-semibold mb-1 ${
                            tip.priority === 'critical' ? 'text-red-400' :
                            tip.priority === 'high' ? 'text-orange-400' :
                            tip.priority === 'medium' ? 'text-blue-400' :
                            tip.priority === 'low' ? 'text-gray-300' :
                            'text-emerald-400'
                          }`}>
                            {tip.title}
                          </h4>
                          <p className="text-sm text-gray-400">{tip.description}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-gray-800 mt-16 py-8 text-center text-sm text-gray-600">
        <p>Girmer — Canadian Tax Calculator & Savings Planner</p>
        <p className="mt-1">Tax rates based on 2025 figures. For informational purposes only.</p>
      </footer>
    </div>
  );
}
